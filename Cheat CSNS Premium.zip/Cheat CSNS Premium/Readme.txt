Indonesia : Buka terlebih dahulu gamenya, lalu Buka Xenos64.exe ( Bagi 64Bit ) / Untuk Xenos32.exe itu ( 32 BIT ), Dan pilih process cstrike-online.exe
Lalu dll pilih Indonesia.dll, Tiap harinya akan ada Update

English : Open the game first, then open Xenos64.exe (Share 64Bit) / For the Xenos32.exe (32 BIT), and select the cstrike-online.exe process
Then select Indonesia.dll etc., Every day there will be an update